import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../Services/user.service';
import { CoreService } from '../Services/core.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit  {
  loginForm!:FormGroup;
  errorMessage: string = '';
  userData = null;

  constructor(private formbuilder:FormBuilder,
    private api:UserService,
    private _coreService:CoreService,
    private route:Router){}
  ngOnInit(): void {
    this.loginForm=this.formbuilder.group(
      {
        username:['',Validators.required],
        password:['',Validators.required]
      }
    )
  }
    Login()
    {
    if (this.loginForm.valid)
    {
      this.api.login(this.loginForm.value).subscribe({
        next: (val: any) => {
          localStorage.setItem("userId", this.loginForm.value.username);
          console.log(localStorage);
          this._coreService.openSnackBar('Login successfully');
          this.route.navigate(['/product']);
        },
        error: (err: any) => {
          console.error(err);
          this.errorMessage = 'Invalid username or password';
          this._coreService.openSnackBar('Please Enter Correct Credentials'); 
        },
      });
    }
    }
  
 

}
