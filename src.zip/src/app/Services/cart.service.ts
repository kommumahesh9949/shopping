import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private cartDetailsSubject = new BehaviorSubject<any[]>([]);
  cartDetails$: Observable<any[]> = this.cartDetailsSubject.asObservable();

  constructor() {}

  updateCartDetails(cartDetails: any[]) {
    this.cartDetailsSubject.next(cartDetails);
  }
  incrementQuantity(cartId: number) {
    // Implement logic to increment quantity in the cartDetails array
    const updatedCartDetails = this.cartDetailsSubject.value.map((cartItem) => {
      if (cartItem.cartId === cartId) {
        cartItem.quantity = (cartItem.quantity || 0) + 1;
      }
      return cartItem;
    });

    this.cartDetailsSubject.next(updatedCartDetails);
  }
}
