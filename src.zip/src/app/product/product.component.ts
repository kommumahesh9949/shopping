import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { UserService } from '../Services/user.service';
import { CoreService } from '../Services/core.service';
import { AddEditComponent } from '../add-edit/add-edit.component';
import { Router } from '@angular/router';
import { CartService } from '../Services/cart.service';
export interface ProductData {
  productid: number;
  productName: string;
  productDescription: string;
  productImage: string;
  createdAt:Date;
  updatedAt:Date;
}

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrl: './product.component.css'
})

export class ProductComponent implements OnInit{
  displayedColumns: string[] = ['productId', 'productName', 'productDescription', 
  'createdAt','updatedAt','Edit','Delete','Add Cart'];
    dataSource!: MatTableDataSource<ProductData>;
    viewType: 'grid' | 'list' = 'grid';
    product!: ProductData;

  
    @ViewChild(MatPaginator) paginator!: MatPaginator;
    @ViewChild(MatSort) sort!: MatSort;
    constructor(private _dilog:MatDialog,
      
    private api:UserService, private _coreService: CoreService,private router:Router,private cartService: CartService){ }
    
    openAddEditForm() {
      this._dilog.open(AddEditComponent);
  }
   getproduct()
   {
    this.api.getproduct()
    .subscribe(
      {
        next:(res:any)=>{
         this.dataSource=new MatTableDataSource(res);
         this.dataSource.paginator=this.paginator;
         this.dataSource.sort=this.sort
        }
      }
    )
  
   }
   EditForm(data: any) {
    const dialogRef = this._dilog.open(AddEditComponent, {
      data,
    });
  
    dialogRef.afterClosed().subscribe({
      next: (val:any) => {
        if (val) {
          this.getproduct();
        }
      },
    });
  }
  deleteEmployee(id: number) {
    const userConfirmed = window.confirm('Are you sure you want to Delete the Product?');
    if (userConfirmed) {
    this.api.deleteProduct(id).subscribe({
      next: (res) => {
        this._coreService.openSnackBar('Product deleted!', 'done');
        this.getproduct();
      },
    
      error: console.log,
    });
  }
}
addToCart(productId: number) {
  console.log('ProductId:', productId);
  this.api.addToCartById(productId).subscribe(
    (response: any) => {
      console.log('Success:', response);
      if (response.updatedCart) {
        this._coreService.openSnackBar('Quantity updated in the cart!', 'done');
      } else {
        this._coreService.openSnackBar('Added To Cart', 'done');
      }

      // Update the cart details in the CartService
      this.cartService.updateCartDetails(response.cartDetails);
    },
    (error) => {
      console.log(error);
      // Handle error if needed
    }
  );
}


   applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
    ngOnInit(): void {
      this.getproduct();
      
    }
    
  }