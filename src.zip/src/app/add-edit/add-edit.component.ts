import { Component,Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { UserService } from '../Services/user.service';
import { CoreService } from '../Services/core.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-edit',
  templateUrl: './add-edit.component.html',
  styleUrl: './add-edit.component.css'
})
export class AddEditComponent implements OnInit {
  articleForm!:FormGroup;
  actionbtn:string='save';
  @ViewChild('f_input') fileInput: any;
  constructor(private formbuilder:FormBuilder,
    @Inject(MAT_DIALOG_DATA) public editData:any,
    private api:UserService,
    private router:Router,
    private _coreService:CoreService,
    private dialogRef: MatDialogRef<AddEditComponent>,){

  }
  ngOnInit(): void {
    this.articleForm=this.formbuilder.group(
      {
        productName:['',Validators.required],
        productDescription: ['',Validators.required],
        productImage:['']
      }
    )
    
  
  if(this.editData)
  {
    this.actionbtn="Update";
    this.articleForm.patchValue(this.editData);
  }
}
  addproduct()
  {
  if (this.articleForm.valid) {
    if (this.editData) {
      this.api
        .updateProduct(this.editData.productId, this.articleForm.value)
        .subscribe({
          next: (val: any) => {
            this._coreService.openSnackBar('Product detail updated!');
            this.dialogRef.close(true);
            window.location.reload();
           
          },
          error: (err: any) => {
            console.error(err);
          },
        });
    } else {
      this.api.addproduct(this.articleForm.value).subscribe({
        next: (val: any) => {
          this._coreService.openSnackBar('Product added successfully');
          this.dialogRef.close(true);
          window.location.reload();
          
        },
        error: (err: any) => {
          console.error(err);
        },
      });
    }
  }
}
  



}
