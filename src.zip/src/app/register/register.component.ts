import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../Services/user.service';
import { CoreService } from '../Services/core.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent implements OnInit {

  RegisterForm!:FormGroup;
  constructor(private formbuilder:FormBuilder,
    private api:UserService,
    private _coreService:CoreService,
    private route:Router){}
  ngOnInit(): void {
    this.RegisterForm=this.formbuilder.group(
      {
        username:['',Validators.required],
        password:['',Validators.required],
        firstname:['',Validators.required],
        lastname:['',Validators.required],
        email:['',Validators.required],
      }
    )
  }
    SignUp()
    {
    if (this.RegisterForm.valid)
    {
      this.api.postsignup(this.RegisterForm.value).subscribe({
        next: (val: any) => {
          this._coreService.openSnackBar('Register successfully');
          this.route.navigate(['/login']);
        },
        error: (err: any) => {
          console.error(err);
          this._coreService.openSnackBar('Please Enter Details'); 
        },
      });
    }

  }
}
